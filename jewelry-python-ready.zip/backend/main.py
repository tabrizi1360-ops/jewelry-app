from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from . import db, crud

app = FastAPI(title='Jewelry App Backend')
app.add_middleware(CORSMiddleware, allow_origins=['*'], allow_credentials=True, allow_methods=['*'], allow_headers=['*'])

@app.on_event('startup')
async def startup():
    db.init_db()
    crud.seed_if_needed()

app.include_router(crud.router, prefix='/api')

@app.get('/')
def root():
    return {'ok': True}
